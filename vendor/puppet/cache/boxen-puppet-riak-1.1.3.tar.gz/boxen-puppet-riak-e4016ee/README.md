# Riak Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-riak.png?branch=master)](https://travis-ci.org/boxen/puppet-riak)

## Usage

```puppet
include riak
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
