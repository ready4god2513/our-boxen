# Backblaze Puppet Module for Boxen

Install [Backblaze](http://www.backblaze.com/), a remote backup service.

## Usage

```puppet
include backblaze
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
