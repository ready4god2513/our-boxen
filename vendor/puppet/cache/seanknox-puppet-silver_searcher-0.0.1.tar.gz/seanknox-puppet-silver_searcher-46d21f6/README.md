# Silver Search Puppet Module for Boxen

Installs the Silver Searcher (ag)

[![Build Status](https://travis-ci.org/boxen/puppet-silver_searcher.png?branch=master)](https://travis-ci.org/boxen/puppet-silver_searcher)

## Usage

```puppet
include silver_searcher
```

## Required Puppet Modules

* `boxen`
